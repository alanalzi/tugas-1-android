package com.example.studentmanagerapp

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var database: SQLiteDatabase
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etFavoriteColor: EditText
    private lateinit var tvData: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShow: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inisialisasi UI
        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etFavoriteColor = findViewById(R.id.etFavoriteColor)
        btnSave = findViewById(R.id.btnSave)
        btnShow = findViewById(R.id.btnShow)
        tvData = findViewById(R.id.tvData)

        // Inisialisasi Database
        val dbHelper = object : SQLiteOpenHelper(this, "StudentDB", null, 2) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL("CREATE TABLE Friends (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, color TEXT)")
            }

            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                db.execSQL("DROP TABLE IF EXISTS Friends")
                onCreate(db)
            }
        }
        database = dbHelper.writableDatabase

        // Save
        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val color = etFavoriteColor.text.toString().trim()

            if (name.isNotEmpty() && phone.isNotEmpty() && color.isNotEmpty()) {
                val values = ContentValues().apply {
                    put("name", name)
                    put("phone", phone)
                    put("color", color)
                }
                database.insert("Friends", null, values)

                // Kosongkan input setelah disimpan
                etName.text.clear()
                etPhone.text.clear()
                etFavoriteColor.text.clear()

                tvData.text = "Data berhasil disimpan!"
                showData()
            } else {
                Toast.makeText(this, "Masukkan data dengan benar!", Toast.LENGTH_SHORT).show()
            }
        }

        // Tombol Show Data
        btnShow.setOnClickListener {
            showData()
        }
    }

    // Untuk data
    private fun showData() {
        val cursor = database.rawQuery("SELECT * FROM Friends", null)
        val stringBuilder = StringBuilder()

        while (cursor.moveToNext()) {
            val name = cursor.getString(1)
            val phone = cursor.getString(2)
            val color = cursor.getString(3)

            stringBuilder.append("Nama: $name\nNo Telfon: $phone\nWarna Favorit: $color\n\n")

            // Ubah warna teks sesuai warna favorit
            try {
                tvData.setTextColor(Color.parseColor(color))
            } catch (e: IllegalArgumentException) {
                tvData.setTextColor(Color.BLACK)
            }
        }
        cursor.close()

        tvData.text = if (stringBuilder.isNotEmpty()) stringBuilder.toString() else "Belum ada data yang disimpan!"
    }
}
